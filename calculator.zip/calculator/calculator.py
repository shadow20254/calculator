a=int(input("Enter a number "))
b=int(input("Enter another number "))
c=input("Enter the operator ( +,-,*,/ ) ")

if c =='+':
    print(a+b)
elif c =='-':
    print(a-b)
elif c =='*':
    print(a*b)
elif c =='/':
    print(a/b)
else:
    print("none")

print('thankyou')